import React from "react";

function ViewComponent(props) {
    return (
        <>
            <header><h2>게시판 - 읽기</h2></header>
            <nav>
                <a href="/" onClick={e => { e.preventDefault(); props.changeMode('list'); }}>목록</a>&nbsp;&nbsp;
                <a href="/" onClick={e => { e.preventDefault(); alert('수정'); }}>수정</a>&nbsp;&nbsp;
                <a href="/" onClick={e => { e.preventDefault(); alert('삭제'); }}>삭제</a>
            </nav>
            <article>
                <table border="1">
                    <tbody>
                        <tr>
                            <td>작성자</td>
                            <td>낙자쌤</td>
                        </tr>
                        <tr>
                            <td>제목</td>
                            <td>오늘은 React 공부하는날</td>
                        </tr>
                        <tr>
                            <td>작성일</td>
                            <td>2023-01-01</td>
                        </tr>
                    </tbody>
                </table>
            </article>
        </>
    );
}

export default ViewComponent;