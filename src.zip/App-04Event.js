import './App.css';

function MyBody(props) {
  const liTag1 = [], liTag2 = []; //빈배열 생성

  for (let i = 0; i < props.propData1.length; i++) {
    console.log(props.propData1[i]);
    liTag1.push(<li key={i}>{props.propData1[i]}</li>);
  };

  let keyCnt = 0;
  for (let row of props.propData2) liTag2.push(<li key={keyCnt++}>{row}</li>);

  return (
    <ol>
  {/* 첫번째 경고창은 고정되 메세지를 알림창으로 띄운다.
  props로 전달된 기능을 자식 컴포넌트에서 그대로 사용하는 형식
  클릭시 새로고침된다.
  
  두번째 경고창은 이벤트 객체 통해 화면 새로고침 되지 않도록 요청 중단시킨다
  react는 기본적으로 비동기방식으로 화면을 전환하므로 화면이 새로고침되면 안된다
  새로고침되면 초기화면으로 전환되기 때문이다. 
  인수로 전달된 문자열리 알림창에 표시된다 */}
      <li><a href="/" onClick={() => { props.onMyAlert1(); }}>프론트엔드</a></li>
      <ul>{liTag1}</ul>
      <li><a href="/" onClick={(event) => { event.preventDefault(); props.onMyAlert2('백엔드'); }}>백엔드</a></li>
      <ul>{liTag2}</ul>
    </ol>
  );
}
//문자열형태의 props를 받아 jsx에 삽입한다
function Tops(props) {
  return (
    <h2>{props.textData}</h2>
  );
}
function App() { //props 로 사용할 배열변수선언
  const myData1 = ['HTML5', 'CSS3', 'JavaScript', 'jQuery'];
  const myData2 = ['Java', 'Oracle', 'JSP', 'Spring Boot', 'PHP'];

  return (
    <div className="App">
      <Tops textData="React - Event 처리" />
      {/* 이벤트 처리 위한 함수 */}
      <MyBody propData1={myData1} propData2={myData2}
        onMyAlert1={function () { alert('알림창을 띄웁니다.'); }}
        onMyAlert2={msg =>alert(msg)} />
    </div>
  );
}
export default App;