import './App.css';
import { useState } from 'react';

/* 컴포넌트 제작시 ui부분의 태그는 반드시 최상위 엘리먼트가 하나만 존재해야한다
하지만 아래처럼 동일한 depth의 엘리먼트가 2개이상 존재한다면 <></>처럼 빈꺽쇄괄호로 
묶어 하나로 만들어주면된다 */
function MyCont1(props) {
  return (
    < >
      <li><a href="/" onClick={event => { event.preventDefault(); props.myModeChange('front'); }}>프론트엔드</a></li>
      <ul>
        <li>HTML5</li>
        <li>CSS3</li>
        <li>JavaScript</li>
        <li>jQuery</li>
      </ul>
    </>
  );
}

function MyCont2(props) {
  return (
    <>
      <li><a href="/" onClick={event => { event.preventDefault(); props.myModeChange('back'); }}>백엔드</a></li>
      <ul>
        <li>Java</li>
        <li>Oracle</li>
        <li>JSP</li>
        <li>Spring Boot</li>
        <li>PHP</li>
      </ul>
    </>
  );
}
/* 탑 컴포넌트 : 화면의 새로고침 차단. props로 전달된 함수 호출. 
이때 인수로 both를 전달하면 state가 해당값으로 변경됨 */
function Tops(props) {
  return (
    <h2><a href="/" onClick={event => { event.preventDefault(); props.myModeChange('both'); }}>React - State 변경하기</a></h2>
  );
}
/* react hook : react 16.8부터 새로 추가된 기능으로 함수형 컴포넌트에서  
state와 생명주기를 연동할수있게해주는 특수함수를 말한다
훅은 import를 먼저진행후 usexxx() 같은 패턴으로 함수를 아래처럼 사용한다
형식] import {useState} from 'react';
useState() : 리액트에서 상태값 가지는 state 값을 설정하거나 읽을때 사용한다.
반환값은 배열인데 0번 요소는 getter, 1번요소는 setter 로 사용할수있다.
const testState = setState('상태값');
const getTs = testState[0]; => 초기값인 '상태값'이 할당됨
const setTs = testState[1]; => 값을 변경할수있는 '함수'
=> 위 문법을 '구조분해할당' 으로 축약하면 다음과 같다
const [getTs, setTs] = setState('상태값'); */
function App() {
  /* ui 전환 위한 state 생성. 초기값은 both이고 변수명은 mode로 지정됨
  또한 이를 변경하기위한 함수는 setMode()로 지정됨
  state 의 값은 임의로 변경할수있으나 그러면 화면이 새로 렌더링되지않는다.
  반드시 변환함수로 state 변경해야만 렌더링되므로 주의해야한다. */
  const [mode, setMode] = useState('both');
  let contents = ''; //컴포넌트 저장하기위한 변수
  /* 각 컴포넌트 별로 mode 변경 위한 함수를 props로 전달하고있다. 
  자식 컴포넌트에서는 해당함수호출시 전달한 매개변수에 따라 mode 값이 변경될것
  mode는 state이므로 변경시 ui가 새로 렌더링되어 화면이 전환된다 */
  if (mode === 'front') {
    contents = <><MyCont1 myModeChange={mode => { setMode(mode); }} /></>
  } else if (mode === 'back') {
    contents = <><MyCont2 myModeChange={mode => { setMode(mode); }} /></>
  } else {
    contents = <><MyCont1 myModeChange={mode => { setMode(mode); }} />
      <MyCont2 myModeChange={mode => { setMode(mode); }} /></>
  }

  return (
    <div className="App">
      <Tops myModeChange={mode => { setMode(mode); }} />
      <ol>{contents}</ol>
    </div>
  );
}
export default App;