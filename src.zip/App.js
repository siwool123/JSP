import './App.css';
import { useState } from 'react';
import ListComponent from './component/ListComponent';
import WriteComponent from './component/WriteComponent';
import ViewComponent from './component/ViewComponent';

function App() {
  const [mode, setMode] = useState('list');
  let contents = '';
  if (mode === 'view') contents = <ViewComponent changeMode={pmode => { setMode(pmode); }} />
  else if (mode === 'write') contents = <WriteComponent changeMode={pmode => { setMode(pmode); }} />
  else contents = <ListComponent changeMode={pmode => { setMode(pmode); }} />

  return (
    <div className="App">
      <h2>React - 모듈화</h2>
      {contents}
    </div>
  );
}
export default App;